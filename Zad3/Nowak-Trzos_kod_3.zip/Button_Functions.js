function addPoints() {
  if (but_functions == 1) {
    but_functions = 0;
  } else {
    if (scene.getPC().length < 1) {
      scene.pushPC(new PointsCollection());
    }
    but_functions = 1;
  }
}
function BegShape() {
  if (but_functions == 2) {
    but_functions = 0;
  } else {
    scene.pushAddedPC(new PointsCollection());
    but_functions = 2;
  }
}
function Clear() {
  scene.clear();
  but_functions = 0;
}
function loadJson() {
  scene.clear();
  but_functions = 0;
}
function saveJson() {
  saveJSON(scene, "data.json");
}
function handleFile(file) {
  scene = new Scene(file.data);
}

function resetAnimation() {
  stepbystep = (stepbystep + 1)%2
  reset_frame = frameCount
}
function debug() {
  dddd = (dddd+1)%2
}
function spawnDataset_and_clear(){
  Clear()
  
  createDatasets(scene, datasetCounter)
  datasetCounter++;
}
function triangulationSwitch_function(){
  triangulationSwitch = (triangulationSwitch+1)%2
}
function stepplus(){
  sstep ++;
}

function mouseClicked() {

  // console.log(but_functions);
  switch (but_functions) {
    case 0:
      break;
    case 1:
      if (mouseX > border && mouseX < w+border && mouseY > border && mouseY < h+border) {
        scene.getPC()[scene.getPC().length - 1].push(new Point(mouseX, mouseY));
      }
      break;
    case 2:
      if (mouseX > border && mouseX < w+border && mouseY > border && mouseY < h+border) {
        scene
          .getAddedPC()
          [scene.getAddedPC().length - 1].push(new Point(mouseX, mouseY));
      }
      break;
    case 3:
      break;
  }
}