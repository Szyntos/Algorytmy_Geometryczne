function classify_verticies(PC) {
  for (let i = 0; i < PC.getArray().length; i++) {
    a = PC.getArray()[i % PC.getArray().length];
    b = PC.getArray()[(i + 1) % PC.getArray().length];
    c = PC.getArray()[(i + 2) % PC.getArray().length];
    if (det(a, b, c) == 1) {
      if (a.y < b.y && c.y < b.y) {
        b.type = "ko";
      } else if (a.y > b.y && c.y > b.y) {
        b.type = "po";
      } else {
        b.type = "pr";
      }
    } else if (det(a, b, c) == -1) {
      if (a.y < b.y && c.y < b.y) {
        b.type = "la";
      } else if (a.y > b.y && c.y > b.y) {
        b.type = "dz";
      } else {
        b.type = "pr";
      }
    } else {
      b.type = "pr";
    }
  }
}

function is_y_monotonic(PC) {
  for (let i = 0; i < PC.getArray().length; i++) {
    if (PC.getArray()[i].type == "la" || PC.getArray()[i].type == "dz") {
      PC.setType("not_monotonic");
      return false;
    }
  }
  if (PC.getArray().length > 2) {
    a = PC.getArray()[PC.getArray().length - 1];
    b = PC.getArray()[0];
    for (let i = 0; i < PC.getArray().length; i++) {
      if (det(a, b, PC.getArray()[i]) < 0) {
        if (
          (a.y < PC.getArray()[i].y && b.y > PC.getArray()[i].y) ||
          (a.y > PC.getArray()[i].y && b.y < PC.getArray()[i].y)
        ) {
          PC.setType("not_monotonic");
          return false;
        }
      }
    }
  }

  PC.setType("monotonic");

  return true;
}

function what_chain(i) {
  if (right.includes(i)) {
    if (left.includes(i)) {
      return "l";
    }
    return "r";
  }
  return "l";
}
function print_stack(string) {
  stack.forEach(function (element) {
    string += element;
    string += ", ";
  });
  console.log(string);
}

function triangulate(PC, frame, animation = 1, step = 0) {
  function drawCurrent(p) {
    if (frame - reset_frame < time * step && animation) {
      tmp = p.type;
      p.type = "current";
      p.draw();
      p.type = tmp;
      return true;
    }
    return false;
  }

  function drawStack() {
    if (frame - reset_frame < time * step && animation) {
      for (let k = 0; k < stack.length; k++) {
        tmp = points[stack[k]].type;
        points[stack[k]].type = "stack";
        points[stack[k]].draw();
        points[stack[k]].type = tmp;
      }

      return true;
    }
    return false;
  }
  function drawCheckTriangle() {
    if (frame - reset_frame < time * step && animation) {
      x = new Line(points[b], points[c]);
      y = new Line(points[a], points[c]);
      z = new Line(points[b], points[a]);
      stroke("rgb(255,140,0)");
      strokeWeight(4);
      x.draw()
      y.draw()
      z.draw()
      stroke(default_stroke);
      strokeWeight(default_stroke_weight);
      return true;
    }
    return false;
  }
  function drawAddedLine(a, b) {
    if (frame - reset_frame < time * step && animation) {
      x = new Line(a, b);
      stroke("rgb(255,0,0)");
      strokeWeight(5);
      x.draw()
      stroke(default_stroke);
      strokeWeight(default_stroke_weight);
      return true;
    }
    return false;
  }
  step = 0;
  time = fr/5;
  LC = new LinesCollection();
  LC.pushArray(points_to_lines(PC.getArray(), 1));
  points = PC.getArray();
  if (points.length < 3 || PC.type != "monotonic") {
          LC.draw(2);
    return;
  }
  min_point = points.reduce((acc, val) => {
    return acc.y > val.y ? acc : val;
  });
  max_point = points.reduce((acc, val) => {
    return acc.y < val.y ? acc : val;
  });
  start = 0;
  stop = 0;
  indices = [];
  for (let i = 0; i < points.length; i++) {
    if (min_point == points[i]) {
      start = i;
      break;
    }
  }
  for (let i = 0; i < points.length; i++) {
    indices.push(i);
    if (max_point == points[i]) {
      stop = i;
    }
  }
  right = [];
  left = [];
  flag = 0;
  for (let i = start; i < points.length + start; i++) {
    if (i % points.length == stop) {
      right.push(i % points.length);
      left.push(start);
      flag = 1;
    }
    if (flag == 0) {
      right.push(i % points.length);
    } else {
      left.push(i % points.length);
    }
  }
  quickSort_y_indices(points, indices, 0, indices.length - 1);
  stroke(0);
  strokeWeight(2);
  fill(255);
  for (let i = 0; i < indices.length; i++) {
    text(i, points[indices[i]].x, points[indices[i]].y + 15);
  }

  stack = [];
  stack.push(indices[0]);
  step++;
  if (drawStack()) {
    return;
  }

  stack.push(indices[1]);
  step++;
  if (drawStack()) {
          LC.draw(2);
    return;
  }
  for (let i = 2; i < indices.length; i++) {
    // console.log(step)
    // print_stack("poczatek fora: ")

    c = indices[i];
    step++
    if (drawStack() && drawCurrent(points[c])) {
            LC.draw(2);
      return;
    }

    // console.log("rozpatrujemy c = ", c)
    // console.log("sprawdzamy czy rozne")
    if (
      ((what_chain(c) == "r" || what_chain(c) == "b") &&
        (what_chain(stack[stack.length - 1]) == "l" ||
          what_chain(stack[stack.length - 1]) == "b")) ||
      ((what_chain(c) == "l" || what_chain(c) == "b") &&
        (what_chain(stack[stack.length - 1]) == "r" ||
          what_chain(stack[stack.length - 1]) == "b"))
    ) {
      // console.log("sa rozne")
      for (let j = 0; j < stack.length; j++) {
        if (!LC.contains(new Line(points[c], points[stack[j]]))) {
          // console.log("dodajemy linie: ", c, stack[j])
          LC.push(points[c], points[stack[j]]);
          step++;
          if (drawStack() && drawCurrent(points[c]) && drawAddedLine(points[c], points[stack[j]])) {
                  LC.draw(2);
            return;
          }
        }
        if (
          !LC.contains(new Line(points[c], points[stack[stack.length - 1]]))
        ) {
          // console.log("dodajemy linie: ", c, stack[stack.length-1])
          LC.push(points[c], points[stack[stack.length - 1]]);
          step++;
          if (drawStack() && drawCurrent(points[c]) && drawAddedLine(points[c], points[stack[stack.length-1]])) {
                  LC.draw(2);
            return;
          }
        }
      }
      stack = [indices[i - 1], c];
    } else {
      // console.log("nie sa rozne")
      // print_stack("przed while: ")
      b = stack.pop();
      a = stack[stack.length - 1];
      // console.log("rozpatrujemy trojkat: ", a, b, c)
      step++
      if (drawStack() && drawCheckTriangle() && drawCurrent(points[c])){
              LC.draw(2);
        return
      }
      while (
        stack.length > 0 &&
        (((what_chain(c) == "l" || what_chain(c) == "b") &&
          det(points[a], points[b], points[c]) > 0) ||
          ((what_chain(c) == "r" || what_chain(c) == "b") &&
            det(points[a], points[b], points[c]) < 0))
      ) {
        // console.log("weszlismy do while")
        if (!LC.contains(new Line(points[b], points[c]))) {
          step++;
          if (drawStack() && drawCheckTriangle() && drawCurrent(points[c]) && drawAddedLine(points[b], points[c])) {
                  LC.draw(2);
            return;
          }
          // console.log("dodajemy linie: ", b, c)
          LC.push(points[b], points[c]);
        }
        if (!LC.contains(new Line(points[a], points[c]))) {
          step++;
          if (drawStack() && drawCheckTriangle() && drawCurrent(points[c]) && drawAddedLine(points[c], points[a])) {
                  LC.draw(2);
            return;
          }
          // console.log("dodajemy linie: ", a, c)
          LC.push(points[a], points[c]);
        }
        if (!LC.contains(new Line(points[b], points[a]))) {
          step++;
          if (drawStack() && drawCheckTriangle() && drawCurrent(points[c]) && drawAddedLine(points[c], points[b])) {
                  LC.draw(2);
            return;
          }
          // console.log("dodajemy linie: ", b, a)
          LC.push(points[b], points[a]);
        }
        // console.log("pop b:", b)
        b = stack.pop();
        if (stack.length > 0){
                  a = stack[stack.length - 1];
        }

        // console.log("rozpatrujemy trojkat: ", a, b, c)
        // stack.pop()
      }
      stack.push(b);
      stack.push(c);
    }
  }
  if (frame - reset_frame == time * step && animation) {
    console.log(LC);
    return
  }
  // LC.draw(2);
  return LC;
}
